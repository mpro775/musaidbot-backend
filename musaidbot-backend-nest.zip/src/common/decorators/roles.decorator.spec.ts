import { RolesDecorator } from './roles.decorator';

describe('RolesDecorator', () => {
  it('should be defined', () => {
    expect(RolesDecorator).toBeDefined();
  });
});
