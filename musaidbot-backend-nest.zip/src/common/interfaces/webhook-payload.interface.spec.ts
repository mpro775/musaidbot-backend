import { WebhookPayloadInterface } from './webhook-payload.interface';

describe('WebhookPayloadInterface', () => {
  it('should be defined', () => {
    expect(WebhookPayloadInterface).toBeDefined();
  });
});
