import { RequestWithUserInterface } from './request-with-user.interface';

describe('RequestWithUserInterface', () => {
  it('should be defined', () => {
    expect(RequestWithUserInterface).toBeDefined();
  });
});
