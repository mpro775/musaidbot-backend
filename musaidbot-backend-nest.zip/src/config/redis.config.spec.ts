import { RedisConfig } from './redis.config';

describe('RedisConfig', () => {
  it('should be defined', () => {
    expect(RedisConfig).toBeDefined();
  });
});
