import { Main } from './main';

describe('Main', () => {
  it('should be defined', () => {
    expect(Main).toBeDefined();
  });
});
