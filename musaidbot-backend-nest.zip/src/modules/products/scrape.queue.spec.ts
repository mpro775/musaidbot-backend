import { ScrapeQueue } from './scrape.queue';

describe('ScrapeQueue', () => {
  it('should be defined', () => {
    expect(ScrapeQueue).toBeDefined();
  });
});
