import { ProductResponseDto } from './product-response.dto';

describe('ProductResponseDto', () => {
  it('should be defined', () => {
    expect(ProductResponseDto).toBeDefined();
  });
});
