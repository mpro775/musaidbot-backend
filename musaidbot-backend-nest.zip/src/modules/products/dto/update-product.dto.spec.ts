import { UpdateProductDto } from './update-product.dto';

describe('UpdateProductDto', () => {
  it('should be defined', () => {
    expect(UpdateProductDto).toBeDefined();
  });
});
