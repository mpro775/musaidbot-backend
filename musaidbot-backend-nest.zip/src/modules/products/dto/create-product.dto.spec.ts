import { CreateProductDto } from './create-product.dto';

describe('CreateProductDto', () => {
  it('should be defined', () => {
    expect(CreateProductDto).toBeDefined();
  });
});
