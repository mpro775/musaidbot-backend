import { LoginDto } from './login.dto';

describe('LoginDto', () => {
  it('should be defined', () => {
    expect(LoginDto).toBeDefined();
  });
});
