import { PlanSchema } from './plan.schema';

describe('PlanSchema', () => {
  it('should be defined', () => {
    expect(PlanSchema).toBeDefined();
  });
});
