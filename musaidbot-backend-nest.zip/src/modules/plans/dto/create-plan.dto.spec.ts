import { CreatePlanDto } from './create-plan.dto';

describe('CreatePlanDto', () => {
  it('should be defined', () => {
    expect(CreatePlanDto).toBeDefined();
  });
});
