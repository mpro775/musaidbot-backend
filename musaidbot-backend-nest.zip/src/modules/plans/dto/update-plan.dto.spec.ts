import { UpdatePlanDto } from './update-plan.dto';

describe('UpdatePlanDto', () => {
  it('should be defined', () => {
    expect(UpdatePlanDto).toBeDefined();
  });
});
