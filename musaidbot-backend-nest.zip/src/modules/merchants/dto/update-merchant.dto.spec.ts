import { UpdateMerchantDto } from './update-merchant.dto';

describe('UpdateMerchantDto', () => {
  it('should be defined', () => {
    expect(UpdateMerchantDto).toBeDefined();
  });
});
