import { CreateMerchantDto } from './create-merchant.dto';

describe('CreateMerchantDto', () => {
  it('should be defined', () => {
    expect(CreateMerchantDto).toBeDefined();
  });
});
