import { WebhookSchema } from './webhook.schema';

describe('WebhookSchema', () => {
  it('should be defined', () => {
    expect(WebhookSchema).toBeDefined();
  });
});
