import { HandleWebhookDto } from './handle-webhook.dto';

describe('HandleWebhookDto', () => {
  it('should be defined', () => {
    expect(HandleWebhookDto).toBeDefined();
  });
});
