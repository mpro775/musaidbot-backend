import { CreateConversationDto } from './create-conversation.dto';

describe('CreateConversationDto', () => {
  it('should be defined', () => {
    expect(CreateConversationDto).toBeDefined();
  });
});
