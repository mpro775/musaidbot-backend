import { ConversationResponseDto } from './conversation-response.dto';

describe('ConversationResponseDto', () => {
  it('should be defined', () => {
    expect(ConversationResponseDto).toBeDefined();
  });
});
