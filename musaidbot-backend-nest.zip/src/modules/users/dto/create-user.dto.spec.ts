import { CreateUserDto } from './create-user.dto';

describe('CreateUserDto', () => {
  it('should be defined', () => {
    expect(CreateUserDto).toBeDefined();
  });
});
